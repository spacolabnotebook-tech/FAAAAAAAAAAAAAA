/**
 * CorporateFit AI Resume & Suitability Analyzer
 * Client-Side Helper and Diagnostics Script
 */

(function () {
  console.log(
    "%c💼 CorporateFit AI Resume Analyzer %cLoaded Successfully",
    "color: #4f46e5; font-weight: bold; font-size: 14px; padding: 4px 8px; background: #eef2ff; border-radius: 4px; border: 1px solid #c7d2fe;",
    "color: #10b981; font-weight: bold; font-size: 12px;"
  );

  // Diagnostics metadata
  const diagnostics = {
    version: "1.0.0",
    loadedAt: new Date().toISOString(),
    environment: window.location.hostname === "localhost" || window.location.hostname === "127.0.0.1" ? "development" : "production",
    isInIframe: window.self !== window.top,
    userAgent: navigator.userAgent
  };

  // Attach diagnostics to the global window object for easy access in developer console
  window.CorporateFitDiagnostics = {
    getSummary: () => diagnostics,
    checkStatus: () => {
      console.log("Checking CorporateFit system status...");
      console.table(diagnostics);
      return "All client-side components active.";
    }
  };

  // Notify of successful initialization
  if (diagnostics.isInIframe) {
    console.log("[Diagnostics] Application is running inside an iframe workspace.");
  } else {
    console.log("[Diagnostics] Application is running in standalone mode.");
  }
})();
