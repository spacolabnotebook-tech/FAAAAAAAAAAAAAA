import {StrictMode} from 'react';
import {createRoot} from 'react-dom/client';
import App from './App.tsx';
import './index.css';

// Global error catcher for UI diagnostics inside AI Studio iframe
if (typeof window !== "undefined") {
  window.addEventListener("error", (event) => {
    console.error("Global Error Caught:", event);
    const root = document.getElementById("root");
    if (root) {
      // Create error element if not already present
      let errDiv = document.getElementById("diagnostic-error-overlay");
      if (!errDiv) {
        errDiv = document.createElement("div");
        errDiv.id = "diagnostic-error-overlay";
        errDiv.className = "fixed inset-0 bg-slate-950 text-red-400 p-8 z-[9999] flex flex-col justify-center items-center font-sans";
        root.appendChild(errDiv);
      }
      errDiv.innerHTML = `
        <div class="max-w-2xl bg-slate-900 border border-red-500/30 p-6 rounded-2xl shadow-2xl text-left">
          <h2 class="text-xl font-bold text-red-500 mb-2">Runtime Exception Detected</h2>
          <p class="text-xs text-white/70 mb-4 font-mono">The browser caught an unhandled script error. See the diagnostics below:</p>
          <pre class="bg-black/50 p-4 rounded-xl text-xs overflow-x-auto border border-white/5 text-left text-red-300 font-mono whitespace-pre-wrap">${event.message || 'Unknown Script Error'}</pre>
          <p class="text-xs text-white/50 mt-4">Source: ${event.filename || 'unknown'} | Line: ${event.lineno || 'unknown'}:${event.colno || 'unknown'}</p>
          <div class="mt-6 flex gap-4">
            <button onclick="window.location.reload()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg cursor-pointer transition-colors text-xs">
              Reload App
            </button>
            <button onclick="document.getElementById('diagnostic-error-overlay').remove()" class="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg cursor-pointer transition-colors text-xs">
              Dismiss Overlay
            </button>
          </div>
        </div>
      `;
    }
  });

  window.addEventListener("unhandledrejection", (event) => {
    console.error("Global Promise Rejection Caught:", event);
    const root = document.getElementById("root");
    if (root) {
      let errDiv = document.getElementById("diagnostic-error-overlay");
      if (!errDiv) {
        errDiv = document.createElement("div");
        errDiv.id = "diagnostic-error-overlay";
        errDiv.className = "fixed inset-0 bg-slate-950 text-red-400 p-8 z-[9999] flex flex-col justify-center items-center font-sans";
        root.appendChild(errDiv);
      }
      errDiv.innerHTML = `
        <div class="max-w-2xl bg-slate-900 border border-red-500/30 p-6 rounded-2xl shadow-2xl text-left">
          <h2 class="text-xl font-bold text-red-500 mb-2">Unhandled Promise Rejection</h2>
          <p class="text-xs text-white/70 mb-4 font-mono">An asynchronous promise was rejected without a catch handler:</p>
          <pre class="bg-black/50 p-4 rounded-xl text-xs overflow-x-auto border border-white/5 text-left text-red-300 font-mono whitespace-pre-wrap">${event.reason?.stack || event.reason || 'Unknown Rejection Reason'}</pre>
          <div class="mt-6 flex gap-4">
            <button onclick="window.location.reload()" class="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold rounded-lg cursor-pointer transition-colors text-xs">
              Reload App
            </button>
            <button onclick="document.getElementById('diagnostic-error-overlay').remove()" class="px-4 py-2 bg-white/10 hover:bg-white/20 text-white font-bold rounded-lg cursor-pointer transition-colors text-xs">
              Dismiss Overlay
            </button>
          </div>
        </div>
      `;
    }
  });
}

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>,
);
