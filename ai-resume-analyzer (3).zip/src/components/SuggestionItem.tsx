import React, { useState } from "react";
import { CheckCircle2, ChevronDown, ChevronUp, Sparkles, AlertCircle, HelpCircle } from "lucide-react";
import { motion, AnimatePresence } from "framer-motion";

interface Suggestion {
  category: string;
  suggestion: string;
  why: string;
  priority: string;
}

interface SuggestionItemProps {
  item: Suggestion;
  index: number;
}

const SuggestionItem: React.FC<SuggestionItemProps> = ({ item, index }) => {
  const [isDone, setIsDone] = useState(false);
  const [isOpen, setIsOpen] = useState(false);

  const getPriorityStyle = (priority: string) => {
    switch (priority?.toLowerCase()) {
      case "high":
        return "bg-rose-500/10 text-rose-300 border-rose-500/20";
      case "medium":
        return "bg-amber-500/10 text-amber-300 border-amber-500/20";
      default:
        return "bg-blue-500/10 text-blue-300 border-blue-500/20";
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: index * 0.05 }}
      className={`border rounded-2xl bg-white/5 backdrop-blur-md transition-all duration-200 ${
        isDone
          ? "border-white/5 bg-white/2 opacity-50"
          : "border-white/10 hover:border-white/20 hover:bg-white/8"
      }`}
    >
      <div className="p-4 flex items-start gap-4">
        {/* Interactive Checkbox */}
        <button
          onClick={() => setIsDone(!isDone)}
          className={`shrink-0 mt-0.5 w-6 h-6 rounded-md border flex items-center justify-center transition-all cursor-pointer ${
            isDone
              ? "bg-blue-600 border-blue-500 text-white shadow-xs"
              : "border-white/20 hover:border-blue-400 text-transparent"
          }`}
        >
          <CheckCircle2 className="w-4 h-4" />
        </button>

        {/* Content Area */}
        <div className="grow">
          <div className="flex flex-wrap items-center gap-2 mb-1.5">
            <span className="text-xs font-semibold text-white/40 font-mono uppercase tracking-wider">
              {item.category}
            </span>
            <span className={`px-2 py-0.5 text-[10px] uppercase tracking-wider font-semibold border rounded-sm font-mono ${getPriorityStyle(item.priority)}`}>
              {item.priority} Priority
            </span>
          </div>

          <p className={`text-sm font-medium leading-relaxed font-sans ${isDone ? "line-through text-white/40" : "text-white/90"}`}>
            {item.suggestion}
          </p>

          <AnimatePresence>
            {isOpen && (
              <motion.div
                initial={{ height: 0, opacity: 0 }}
                animate={{ height: "auto", opacity: 1 }}
                exit={{ height: 0, opacity: 0 }}
                transition={{ duration: 0.2 }}
                className="overflow-hidden"
              >
                <div className="mt-3 pt-3 border-t border-white/10 flex gap-2.5 items-start bg-white/5 p-3 rounded-xl border border-white/5">
                  <HelpCircle className="w-4.5 h-4.5 text-white/40 shrink-0 mt-0.5" />
                  <div>
                    <span className="text-[10px] font-bold text-white/40 block mb-0.5 uppercase tracking-wider">WHY THIS MATTERS</span>
                    <p className="text-xs text-white/70 leading-relaxed">
                      {item.why}
                    </p>
                  </div>
                </div>
              </motion.div>
            )}
          </AnimatePresence>
        </div>

        {/* Toggle Expand Arrow */}
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="shrink-0 p-1 text-white/40 hover:text-white hover:bg-white/10 rounded-lg transition-colors cursor-pointer"
          title="See impact context"
        >
          {isOpen ? <ChevronUp className="w-5 h-5" /> : <ChevronDown className="w-5 h-5" />}
        </button>
      </div>
    </motion.div>
  );
};

export default SuggestionItem;
