import React from "react";
import { motion } from "framer-motion";

interface RatingBarProps {
  name: string;
  score: number; // 1-10
  feedback: string;
}

const RatingBar: React.FC<RatingBarProps> = ({ name, score, feedback }) => {
  // Normalize score to percentage
  const percentage = Math.min(Math.max(score * 10, 0), 100);

  // Color selection based on score maturity
  const getColorClass = (s: number) => {
    if (s >= 8) {
      return {
        bg: "bg-emerald-500",
        text: "text-emerald-400",
        border: "border-emerald-500/20",
        lightBg: "bg-emerald-500/5"
      };
    }
    if (s >= 5) {
      return {
        bg: "bg-blue-500",
        text: "text-blue-400",
        border: "border-blue-500/20",
        lightBg: "bg-blue-500/5"
      };
    }
    return {
      bg: "bg-amber-500",
      text: "text-amber-400",
      border: "border-amber-500/20",
      lightBg: "bg-amber-500/5"
    };
  };

  const colors = getColorClass(score);

  return (
    <div className={`p-4 border rounded-2xl ${colors.lightBg} ${colors.border} backdrop-blur-md transition-all duration-200 shadow-xs hover:border-white/20`}>
      <div className="flex justify-between items-center mb-2">
        <span className="font-semibold text-white text-sm md:text-base">{name}</span>
        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-semibold ${colors.bg}/20 ${colors.text} border ${colors.border}`}>
          {score} / 10
        </span>
      </div>
      
      {/* Background tracking line */}
      <div className="w-full bg-white/10 rounded-full h-2 overflow-hidden mb-3">
        <motion.div
          className={`h-full ${colors.bg}`}
          initial={{ width: 0 }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.8, ease: "easeOut" }}
        />
      </div>

      <p className="text-xs md:text-sm text-white/70 leading-relaxed font-normal">
        {feedback}
      </p>
    </div>
  );
};

export default RatingBar;
